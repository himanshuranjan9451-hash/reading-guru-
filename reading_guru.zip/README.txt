Reading Guru - Starter Flutter project
Files included: pubspec.yaml and lib/ folder with main.dart and screens/services/models.
How to use:
1) Install Flutter SDK and set up environment.
2) Unzip this project into a folder (e.g., reading_guru).
3) From terminal run:
   flutter pub get
   flutter run
Notes:
- You still need to add Android/iOS platform-level permissions as described in the earlier chat.
- For best results install device TTS en-IN voice or integrate Google Cloud TTS.
