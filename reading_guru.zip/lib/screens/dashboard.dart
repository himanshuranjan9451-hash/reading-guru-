import 'package:flutter/material.dart';
import 'upload_screen.dart';
import 'saved_screen.dart';

class DashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Reading Guru'),
        actions: [
          IconButton(
            icon: Icon(Icons.settings),
            onPressed: () => Navigator.pushNamed(context, '/settings'),
          )
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Card(
              child: ListTile(
                title: Text('Upload PDF / Image'),
                subtitle: Text('PDF ya photo upload karke text suniye aur samjhiye'),
                trailing: Icon(Icons.upload_file),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => UploadScreen())),
              ),
            ),
            SizedBox(height: 16),
            Expanded(child: SavedScreen())
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        child: Icon(Icons.upload_file),
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => UploadScreen())),
      ),
    );
  }
}
