import 'package:flutter/material.dart';
import '../models/document.dart';
import '../services/tts_service.dart';

class PlayerScreen extends StatefulWidget {
  final Document doc;
  PlayerScreen({required this.doc});
  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  final TTSService tts = TTSService();
  bool playing = false;

  Future togglePlay() async {
    if (!playing) {
      await tts.speak(widget.doc.extractedText);
      setState(() => playing = true);
    } else {
      await tts.stop();
      setState(() => playing = false);
    }
  }

  @override
  void dispose() {
    tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.doc.title),
      ),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          children: [
            Text('Preview', style: TextStyle(fontWeight: FontWeight.bold)),
            Expanded(child: SingleChildScrollView(child: Text(widget.doc.extractedText))),
            SizedBox(height: 8),
            ElevatedButton.icon(
              icon: Icon(playing ? Icons.pause : Icons.play_arrow),
              label: Text(playing ? 'Pause' : 'Play'),
              onPressed: togglePlay,
            ),
            SizedBox(height: 8),
            ExpansionTile(
              title: Text('Hindi Explanation'),
              children: [Padding(padding: EdgeInsets.all(8), child: Text(widget.doc.hindiExplain))],
            )
          ],
        ),
      ),
    );
  }
}
