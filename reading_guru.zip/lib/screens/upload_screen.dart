import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../services/ocr_service.dart';
import '../services/tts_service.dart';
import '../services/db_service.dart';
import '../models/document.dart';

class UploadScreen extends StatefulWidget {
  @override
  State<UploadScreen> createState() => _UploadScreenState();
}

class _UploadScreenState extends State<UploadScreen> {
  final ImagePicker _picker = ImagePicker();
  File? _file;
  String _extracted = '';
  String _hindiExplain = '';
  bool _loading = false;
  OCRService ocr = OCRService();
  TTSService tts = TTSService();

  Future pickImage() async {
    final XFile? img = await _picker.pickImage(source: ImageSource.gallery);
    if (img == null) return;
    setState(() {
      _file = File(img.path);
      _extracted = '';
    });
  }

  Future extract() async {
    if (_file == null) return;
    setState(() => _loading = true);
    final text = await ocr.extractTextFromImage(_file!);
    setState(() {
      _extracted = text;
      _hindiExplain = _generateHindiExplain(text);
      _loading = false;
    });
  }

  String _generateHindiExplain(String text) {
    final sentences = text.split(RegExp(r'(?<=[.!?])\s+'));
    final take = sentences.take(3).join(' ');
    return "Saar: " + take + "\n(Simplified Hindi explanation: ऊपर दिया हुआ मुख्य सार है)";
  }

  Future playTTS() async {
    if (_extracted.isEmpty) return;
    await tts.speak(_extracted);
  }

  Future saveDoc() async {
    if (_file == null) return;
    final doc = Document(
      title: 'Document \${DateTime.now().millisecondsSinceEpoch}',
      filepath: _file!.path,
      extractedText: _extracted,
      hindiExplain: _hindiExplain,
      createdAt: DateTime.now().millisecondsSinceEpoch,
    );
    await DBService.insertDocument(doc);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Saved')));
    Navigator.pop(context);
  }

  @override
  void dispose() {
    ocr.dispose();
    tts.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Upload')),
      body: Padding(
        padding: EdgeInsets.all(12),
        child: Column(
          children: [
            ElevatedButton.icon(
              icon: Icon(Icons.photo),
              label: Text('Pick Image'),
              onPressed: pickImage,
            ),
            if (_file != null) ...[
              SizedBox(height: 8),
              Expanded(child: Image.file(_file!)),
              SizedBox(height: 8),
              ElevatedButton(
                onPressed: _loading ? null : extract,
                child: Text(_loading ? 'Extracting...' : 'Extract Text'),
              ),
            ],
            if (_extracted.isNotEmpty) ...[
              SizedBox(height: 12),
              Text('Extracted Text:', style: TextStyle(fontWeight: FontWeight.bold)),
              Expanded(child: SingleChildScrollView(child: Text(_extracted))),
              SizedBox(height: 8),
              Row(
                children: [
                  ElevatedButton.icon(
                    icon: Icon(Icons.play_arrow),
                    label: Text('Play'),
                    onPressed: playTTS,
                  ),
                  SizedBox(width: 8),
                  ElevatedButton.icon(
                    icon: Icon(Icons.save),
                    label: Text('Save'),
                    onPressed: saveDoc,
                  ),
                ],
              ),
              SizedBox(height: 8),
              Text('Hindi Explain:', style: TextStyle(fontWeight: FontWeight.bold)),
              Text(_hindiExplain),
            ]
          ],
        ),
      ),
    );
  }
}
