import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'screens/dashboard.dart';
import 'services/db_service.dart';
import 'providers/theme_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DBService.init(); // initialize SQLite
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => ThemeProvider(),
      child: Consumer<ThemeProvider>(builder: (context, themeProv, _) {
        return MaterialApp(
          title: 'Reading Guru',
          theme: ThemeData.light(),
          darkTheme: ThemeData.dark(),
          themeMode: themeProv.isDark ? ThemeMode.dark : ThemeMode.light,
          home: DashboardScreen(),
          routes: {
            '/settings': (context) => Container() // placeholder if route used
          },
        );
      }),
    );
  }
}
