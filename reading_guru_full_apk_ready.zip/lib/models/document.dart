class Document {
  int? id;
  String title;
  String filepath;
  String extractedText;
  String hindiExplain;
  String? audioPath;
  int createdAt;

  Document({
    this.id,
    required this.title,
    required this.filepath,
    required this.extractedText,
    required this.hindiExplain,
    this.audioPath,
    required this.createdAt,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'filepath': filepath,
      'extracted_text': extractedText,
      'hindi_explanation': hindiExplain,
      'audio_path': audioPath,
      'created_at': createdAt,
    };
  }

  factory Document.fromMap(Map<String, dynamic> m) => Document(
        id: m['id'],
        title: m['title'],
        filepath: m['filepath'],
        extractedText: m['extracted_text'],
        hindiExplain: m['hindi_explanation'],
        audioPath: m['audio_path'],
        createdAt: m['created_at'],
      );
}
