import 'package:flutter/material.dart';
import '../services/db_service.dart';
import '../models/document.dart';
import 'player_screen.dart';

class SavedScreen extends StatefulWidget {
  @override
  State<SavedScreen> createState() => _SavedScreenState();
}

class _SavedScreenState extends State<SavedScreen> {
  List<Document> docs = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future load() async {
    final list = await DBService.getDocuments();
    setState(() => docs = list);
  }

  @override
  Widget build(BuildContext context) {
    if (docs.isEmpty) return Center(child: Text('No saved documents'));
    return ListView.builder(
      itemCount: docs.length,
      itemBuilder: (ctx, i) {
        final d = docs[i];
        return Dismissible(
          key: Key(d.id.toString()),
          onDismissed: (_) async {
            await DBService.deleteDocument(d.id!);
            load();
          },
          background: Container(color: Colors.red, child: Icon(Icons.delete, color: Colors.white)),
          child: ListTile(
            title: Text(d.title),
            subtitle: Text(d.extractedText.length > 80 ? d.extractedText.substring(0, 80) + '...' : d.extractedText),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerScreen(doc: d))),
          ),
        );
      },
    );
  }
}
