import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../services/tts_service.dart';

class SettingsScreen extends StatelessWidget {
  final TTSService tts = TTSService();
  @override
  Widget build(BuildContext context) {
    final themeProv = Provider.of<ThemeProvider>(context);
    return Scaffold(
      appBar: AppBar(title: Text('Settings')),
      body: ListView(
        children: [
          SwitchListTile(
            title: Text('Dark Theme'),
            value: themeProv.isDark,
            onChanged: (v) => themeProv.setDark(v),
          ),
          ListTile(
            title: Text('TTS Voice (device)'),
            subtitle: Text('Uses device voices; enable Google Cloud for lifelike Indian voices'),
          ),
          ListTile(
            title: Text('TTS Rate'),
            subtitle: Text('Adjust speed in player'),
          ),
        ],
      ),
    );
  }
}
