import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/document.dart';

class DBService {
  static Database? _db;
  static Future<void> init() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'reading_guru.db');
    _db = await openDatabase(path, version: 1,
        onCreate: (db, version) async {
      await db.execute('''
        CREATE TABLE documents(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          title TEXT,
          filepath TEXT,
          extracted_text TEXT,
          hindi_explanation TEXT,
          audio_path TEXT,
          created_at INTEGER
        )
      ''');
    });
  }

  static Future<int> insertDocument(Document doc) async {
    return await _db!.insert('documents', doc.toMap());
  }

  static Future<List<Document>> getDocuments() async {
    final res = await _db!.query('documents', orderBy: 'created_at DESC');
    return res.map((e) => Document.fromMap(e)).toList();
  }

  static Future<int> deleteDocument(int id) async {
    return await _db!.delete('documents', where: 'id = ?', whereArgs: [id]);
  }

  static Future<int> updateDocument(Document doc) async {
    return await _db!.update('documents', doc.toMap(),
        where: 'id = ?', whereArgs: [doc.id]);
  }
}
