import 'dart:io';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:pdf_text/pdf_text.dart';

class OCRService {
  final TextRecognizer _recognizer = TextRecognizer();

  Future<String> extractTextFromImage(File imageFile) async {
    final inputImage = InputImage.fromFile(imageFile);
    final result = await _recognizer.processImage(inputImage);
    String text = result.text;
    return text;
  }

  Future<String> extractTextFromPdf(File pdfFile) async {
    // Simple approach using pdf_text package
    final pdfText = await PDFDoc.fromFile(pdfFile);
    String all = await pdfText.text;
    return all;
  }

  void dispose() {
    _recognizer.close();
  }
}
