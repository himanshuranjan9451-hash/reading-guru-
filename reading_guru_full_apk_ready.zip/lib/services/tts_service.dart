import 'package:flutter_tts/flutter_tts.dart';

class TTSService {
  final FlutterTts _tts = FlutterTts();

  TTSService() {
    _tts.setLanguage('en-IN'); // try en-IN for Indian English; adjust per device
    _tts.setSpeechRate(0.45);
    _tts.setVolume(1.0);
    _tts.setPitch(1.0);
  }

  Future speak(String text) async {
    await _tts.speak(text);
  }

  Future stop() async {
    await _tts.stop();
  }

  Future setRate(double r) async => await _tts.setSpeechRate(r);
  Future setPitch(double p) async => await _tts.setPitch(p);
}
